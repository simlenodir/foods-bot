export default {
    national: "National foods 🍝",
    eropean: "European foods 🍖",
    fast: "Fast foods 🍔",
    sea: "Sea foods 🍚",
    main_menu: "Back to menu 🔙"
}